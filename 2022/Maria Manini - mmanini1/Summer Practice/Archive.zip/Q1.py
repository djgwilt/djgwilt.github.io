print(count)
double = 2 * num
num = int(num)
for count in range(num,treble+1,1):
num = input("Enter a number: ")
if count != double:
treble = 3 * num