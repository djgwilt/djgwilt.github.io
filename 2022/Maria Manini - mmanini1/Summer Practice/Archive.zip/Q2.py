r = _____(input("Enter the radius: "))
area = _____
print(f"The area is _____ squared cm")