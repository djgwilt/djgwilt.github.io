number = _____("Enter a number: ")
print(number _____ )
print(number _____ )
print(number _____ )