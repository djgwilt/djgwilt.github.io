document.onkeydown = checkKey

var xDir = 0
var yDir = 0

var column = 0
var row = 0

var intervalHandle

var carFlipped = false

function checkKey(e) {
    e = e || window.event
    if (e.keyCode == '39') {
      xDir = 1
      yDir = 0
      carFlipped = false
    } else if (e.keyCode == '37') {
	    xDir = -1
      yDir = 0
      carFlipped = true
    } else if (e.keyCode == '38') {
      yDir = -1
      xDir = 0
    } else if (e.keyCode == '40') {
      yDir = 1
      xDir = 0
    }
}

function runGame() {
	intervalHandle = setInterval(updatePosition, 250)
}

function updatePosition() {
	if (xDir != 0 || yDir != 0) {
		
    document.getElementById("R" + row + "C" + column).className = "Empty"
    
    column += xDir
    row += yDir
    
    cell = document.getElementById("R" + row + "C" + column)
    if (!cell || cell.className == "wall1") {
		handleCrash()
  } else if (!cell || cell.className == "wall2") {
    handleCrash()
  } else if (!cell || cell.className == "wall3") {
    handleCrash()
  } else if (!cell || cell.className == "wall4") {
    handleCrash()
  } else if (!cell || cell.className == "wall5") {
    handleCrash()
	} else if (cell.className == "flag") {
		handleWin()
	} else {
      if (carFlipped) {
        cell.className = "CarFlipped"
      } else{
        cell.className = "Car"
      }
    }
	}
}

function handleCrash() {
	window.clearInterval(intervalHandle)
	document.getElementById("Message").innerText = "Oops you crashed..."
}
function handleWin() {
	window.clearInterval(intervalHandle)
	document.getElementById("Message").innerText = "well done you win!";
}
